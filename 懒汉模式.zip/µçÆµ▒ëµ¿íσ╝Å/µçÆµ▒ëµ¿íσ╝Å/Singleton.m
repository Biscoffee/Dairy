//
//  Singleton.m
//  懒汉模式
//
//  Created by 吴桐 on 2025/5/17.
//



// Singleton.m
#import "Singleton.h"

static id _instance = nil;  //定义static全局变量

@implementation Singleton

+ (id) shareInstance {
    return [[self alloc] init];
}

+ (id) allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

- (id)copyWithZone:(NSZone *)zone {
    return _instance;
}

- (id)mutableCopyWithZone:(NSZone *)zone {
    return _instance;
}

@end
