//
//  main.m
//  懒汉模式
//
//  Created by 吴桐 on 2025/5/17.
//

// main.m
#import <Foundation/Foundation.h>
#import "Singleton.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 获取两个实例
        Singleton *s1 = [Singleton sharedInstance];
        Singleton *s2 = [Singleton sharedInstance];

        // 输出地址判断是否为同一个对象
        NSLog(@"s1 = %p", s1);
        NSLog(@"s2 = %p", s2);

        // 比较是否为同一对象
        if (s1 == s2) {
            NSLog(@"s1 和 s2 是同一个实例（单例成功）");
        } else {
            NSLog(@"s1 和 s2 不是同一个实例（单例失败）");
        }

        // 测试 alloc init 也不能创建新的实例
        Singleton *s3 = [[Singleton alloc] init];
        NSLog(@"s3 = %p", s3);

        if (s1 == s3) {
            NSLog(@"alloc/init 返回的也是同一个实例");
        } else {
            NSLog(@"alloc/init 返回了新的实例，单例实现有问题");
        }
    }
    return 0;
}

