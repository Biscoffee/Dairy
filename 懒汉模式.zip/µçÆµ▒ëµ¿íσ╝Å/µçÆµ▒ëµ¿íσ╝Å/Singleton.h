//
//  Singleton.h
//  懒汉模式
//
//  Created by 吴桐 on 2025/5/17.
//

// Singleton.h
#import <Foundation/Foundation.h>

@interface Singleton : NSObject <NSCopying, NSMutableCopying>
+ (instancetype)sharedInstance;
@end
